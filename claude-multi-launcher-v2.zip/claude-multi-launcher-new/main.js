const { app, BrowserWindow, BrowserView, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

const GAP = 4;
const TOP_BAR_HEIGHT = 44;
const SIDEBAR_WIDTH = 230;
const LIST_VIEW_THRESHOLD = 5;
const CHROME_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const STATE_FILE = path.join(app.getPath('userData'), 'window-state.json');

let mainWindow = null;
let panes = [];
let nextId = 1;
let fullscreenId = null;
let selectedId = null;
let sidebarCollapsed = false;
let paneLabels = {};

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    }
  } catch (_) {}
  return null;
}

function saveState() {
  try {
    const state = {
      panes: panes.map((p) => ({ id: p.id, label: paneLabels[p.id] })),
      nextId,
      selectedId,
      sidebarCollapsed,
    };
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (_) {}
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#15171c',
    title: 'Claude Multi',
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload-host.js'),
    },
  });

  mainWindow.removeMenu();
  mainWindow.loadFile(path.join(__dirname, 'background.html'));

  const saved = loadState();

  if (saved && saved.panes && saved.panes.length > 0) {
    nextId = saved.nextId || 1;
    sidebarCollapsed = saved.sidebarCollapsed || false;

    for (const p of saved.panes) {
      restorePane(p.id, p.label);
    }

    selectedId = saved.selectedId && panes.find((p) => p.id === saved.selectedId)
      ? saved.selectedId
      : panes[panes.length - 1].id;
  } else {
    for (let i = 0; i < LIST_VIEW_THRESHOLD; i++) createPane();
  }

  mainWindow.webContents.once('did-finish-load', relayout);
  mainWindow.on('resize', relayout);
  mainWindow.on('close', saveState);
  mainWindow.on('closed', () => {
    mainWindow = null;
    panes = [];
    paneLabels = {};
  });
}

function makeView(id) {
  const view = new BrowserView({
    webPreferences: {
      partition: `persist:claude-session-${id}`,
      preload: path.join(__dirname, 'preload-overlay.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  view.webContents.setUserAgent(CHROME_UA);
  mainWindow.addBrowserView(view);
  view.webContents.loadURL('https://claude.ai');
  return view;
}

function restorePane(id, label) {
  const view = makeView(id);
  paneLabels[id] = label;
  panes.push({ id, view });
  if (id >= nextId) nextId = id + 1;
}

function getNextLabel() {
  const usedNumbers = Object.values(paneLabels)
    .map((label) => {
      const match = label.match(/^Окно (\d+)$/);
      return match ? parseInt(match[1], 10) : null;
    })
    .filter((n) => n !== null);

  let num = 1;
  while (usedNumbers.includes(num)) num++;
  return `Окно ${num}`;
}

function createPane() {
  const id = nextId++;
  const view = makeView(id);
  paneLabels[id] = getNextLabel();
  panes.push({ id, view });
  selectedId = id;
  relayout();
  saveState();
  return id;
}

function closePane(id) {
  if (panes.length <= 1) return;
  const idx = panes.findIndex((p) => p.id === id);
  if (idx === -1) return;

  const [pane] = panes.splice(idx, 1);
  mainWindow.removeBrowserView(pane.view);
  delete paneLabels[id];

  if (fullscreenId === id) fullscreenId = null;
  if (selectedId === id) {
    selectedId = panes.length ? panes[panes.length - 1].id : null;
  }
  relayout();
  saveState();
}

function getContentBounds() {
  const [width, height] = mainWindow.getContentSize();
  return { width, height };
}

function computeGridLayout(n, width, height) {
  if (n <= 1) return [{ x: 0, y: 0, width, height }];

  if (n === 2) {
    const w = Math.floor((width - GAP) / 2);
    return [
      { x: 0, y: 0, width: w, height },
      { x: w + GAP, y: 0, width: width - GAP - w, height },
    ];
  }

  if (n === 3) {
    const w = Math.floor((width - GAP * 2) / 3);
    const last = width - GAP * 2 - w * 2;
    return [
      { x: 0, y: 0, width: w, height },
      { x: w + GAP, y: 0, width: w, height },
      { x: (w + GAP) * 2, y: 0, width: last, height },
    ];
  }

  if (n === 4) {
    const w = Math.floor((width - GAP) / 2);
    const w2 = width - GAP - w;
    const h = Math.floor((height - GAP) / 2);
    const h2 = height - GAP - h;
    return [
      { x: 0, y: 0, width: w, height: h },
      { x: w + GAP, y: 0, width: w2, height: h },
      { x: 0, y: h + GAP, width: w, height: h2 },
      { x: w + GAP, y: h + GAP, width: w2, height: h2 },
    ];
  }

  const topHeight = Math.floor((height - GAP) / 2);
  const bottomHeight = height - GAP - topHeight;
  const topWidth = Math.floor((width - GAP * 2) / 3);
  const lastTopWidth = width - GAP * 2 - topWidth * 2;
  const bottomWidth = Math.floor((width - GAP) / 2);
  const lastBottomWidth = width - GAP - bottomWidth;

  return [
    { x: 0, y: 0, width: topWidth, height: topHeight },
    { x: topWidth + GAP, y: 0, width: topWidth, height: topHeight },
    { x: (topWidth + GAP) * 2, y: 0, width: lastTopWidth, height: topHeight },
    { x: 0, y: topHeight + GAP, width: bottomWidth, height: bottomHeight },
    {
      x: bottomWidth + GAP,
      y: topHeight + GAP,
      width: lastBottomWidth,
      height: bottomHeight,
    },
  ];
}

function relayout() {
  if (!mainWindow || panes.length === 0) return;

  const { width, height } = getContentBounds();
  const listView = panes.length > LIST_VIEW_THRESHOLD;
  const top = TOP_BAR_HEIGHT;
  const left = listView && !sidebarCollapsed ? SIDEBAR_WIDTH : 0;
  const areaW = Math.max(width - left, 0);
  const areaH = Math.max(height - top, 0);

  if (listView) {
    if (selectedId == null || !panes.find((p) => p.id === selectedId)) {
      selectedId = panes[panes.length - 1].id;
    }
    panes.forEach((p) => {
      if (p.id === selectedId) {
        p.view.setBounds({ x: left, y: top, width: areaW, height: areaH });
      } else {
        p.view.setBounds({ x: 0, y: 0, width: 0, height: 0 });
      }
    });
  } else {
    if (fullscreenId != null && panes.find((p) => p.id === fullscreenId)) {
      panes.forEach((p) => {
        if (p.id === fullscreenId) {
          p.view.setBounds({ x: 0, y: top, width, height: areaH });
        } else {
          p.view.setBounds({ x: 0, y: 0, width: 0, height: 0 });
        }
      });
    } else {
      const rects = computeGridLayout(panes.length, width, areaH);
      panes.forEach((p, i) => {
        const r = rects[i];
        p.view.setBounds({ x: r.x, y: top + r.y, width: r.width, height: r.height });
      });
    }
  }

  broadcastHostState(listView);
  broadcastPaneModes(listView);
}

function broadcastHostState(listView) {
  if (!mainWindow) return;
  mainWindow.webContents.send('host:state', {
    panes: panes.map((p) => ({ id: p.id, label: paneLabels[p.id] || `Окно ${p.id}` })),
    listView,
    selectedId,
    sidebarCollapsed,
  });
}

function broadcastPaneModes(listView) {
  panes.forEach((p) => {
    let mode;
    if (listView) {
      mode = sidebarCollapsed ? 'sidebar-hidden' : 'sidebar-shown';
    } else {
      mode = fullscreenId === p.id ? 'fullscreen' : 'grid';
    }
    p.view.webContents.send('pane-mode', mode);
  });
}

ipcMain.on('toggle-pane', (event) => {
  const pane = panes.find((p) => p.view.webContents === event.sender);
  if (!pane) return;

  if (panes.length <= LIST_VIEW_THRESHOLD) {
    fullscreenId = fullscreenId === pane.id ? null : pane.id;
    relayout();
  }
});

ipcMain.on('request-exit-fullscreen', (event) => {
  const pane = panes.find((p) => p.view.webContents === event.sender);
  if (!pane) return;
  if (panes.length <= LIST_VIEW_THRESHOLD && fullscreenId === pane.id) {
    fullscreenId = null;
    relayout();
  }
});

ipcMain.on('host:create-session', () => createPane());
ipcMain.on('host:select-session', (event, id) => {
  selectedId = id;
  relayout();
});
ipcMain.on('host:close-session', (event, id) => closePane(id));
ipcMain.on('host:rename-session', (event, { id, label }) => {
  if (Object.prototype.hasOwnProperty.call(paneLabels, id)) {
    paneLabels[id] = label;
    saveState();
    relayout();
  }
});
ipcMain.on('host:toggle-sidebar', () => {
  sidebarCollapsed = !sidebarCollapsed;
  saveState();
  relayout();
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
