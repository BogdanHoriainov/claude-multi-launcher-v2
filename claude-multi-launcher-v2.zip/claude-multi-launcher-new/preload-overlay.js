const { ipcRenderer } = require('electron');

function injectOverlay() {
  if (!document.body || document.getElementById('__claude_multi_btn')) return;

  const btn = document.createElement('button');
  btn.id = '__claude_multi_btn';
  btn.title = 'Развернуть на весь экран';
  btn.innerText = '⛶';

  Object.assign(btn.style, {
    position: 'fixed',
    bottom: '16px',
    right: '16px',
    zIndex: 2147483647,
    width: '36px',
    height: '36px',
    borderRadius: '50%',
    border: '1px solid rgba(255,255,255,0.15)',
    background: 'rgba(20,20,25,0.55)',
    color: '#fff',
    fontSize: '17px',
    lineHeight: '1',
    cursor: 'pointer',
    boxShadow: '0 2px 10px rgba(0,0,0,0.4)',
    display: 'none',
    alignItems: 'center',
    justifyContent: 'center',
    backdropFilter: 'blur(4px)',
    transition: 'background 0.15s ease',
  });

  btn.addEventListener('mouseenter', () => {
    btn.style.background = 'rgba(45,45,52,0.9)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.background = 'rgba(20,20,25,0.55)';
  });
  btn.addEventListener('click', () => ipcRenderer.send('toggle-pane'));

  document.body.appendChild(btn);
}

window.addEventListener('DOMContentLoaded', () => {
  injectOverlay();
  const observer = new MutationObserver(injectOverlay);
  observer.observe(document.body, { childList: true });
});

ipcRenderer.on('pane-mode', (_event, mode) => {
  const btn = document.getElementById('__claude_multi_btn');
  if (!btn) return;

  if (mode === 'fullscreen') {
    btn.style.display = 'flex';
    btn.innerText = '⤡';
    btn.title = 'Свернуть назад в сетку (Esc)';
  } else if (mode === 'grid') {
    btn.style.display = 'flex';
    btn.innerText = '⛶';
    btn.title = 'Развернуть на весь экран';
  } else {
    btn.style.display = 'none';
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') ipcRenderer.send('request-exit-fullscreen');
});
